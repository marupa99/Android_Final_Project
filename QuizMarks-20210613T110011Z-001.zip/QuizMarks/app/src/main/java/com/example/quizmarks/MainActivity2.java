package com.example.quizmarks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    int marks = 0;
    int prev, result;
    RadioGroup myradiogroup;
    RadioButton selectedradiobutton;
    String selectedvalue;
    public static String quixmark = "Com.example. myapplication";

    @Override
    protected void onCreate ( Bundle savedInstanceState ) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent mygetIntent = getIntent();
        prev = mygetIntent.getIntExtra(MainActivity.quixmarks, 0);
        myradiogroup = findViewById(R.id.radiogroupid);

    }
        public void submitfunction (View view ){


            int radiobutton = myradiogroup.getCheckedRadioButtonId();
            selectedradiobutton = findViewById(radiobutton);
            selectedvalue = selectedradiobutton.getText().toString();

            if (selectedvalue.equals("Apple")) {

                marks = 5;
            } else {
                marks = 0;
            }
            result = marks + prev;


            Intent myIntent = new Intent(MainActivity2.this, MainActivity3.class);

            myIntent.putExtra(quixmark, result);
            startActivity(myIntent);

        }


    }
