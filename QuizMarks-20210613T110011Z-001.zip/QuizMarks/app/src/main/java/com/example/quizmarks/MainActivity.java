
package com.example.quizmarks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    int marks = 0;
    RadioGroup myradiogroup;
    RadioButton selectedradiobutton;
    String selectedvalue;

    public static String quixmarks = "Com.example. myapplication";

    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myradiogroup = findViewById(R.id.radiogroupid);
    }


        public void submit (View view ){


            int radiobutton = myradiogroup.getCheckedRadioButtonId();
            selectedradiobutton = findViewById(radiobutton);
            selectedvalue = selectedradiobutton.getText().toString();

            if (selectedvalue.equals("Cox's Bazer")) {

                marks = 5;


            } else {
                marks = 0;


            }

            Intent myIntent = new Intent(MainActivity.this, MainActivity2.class);
            myIntent.putExtra(quixmarks, marks);
            startActivity(myIntent);

        }


}