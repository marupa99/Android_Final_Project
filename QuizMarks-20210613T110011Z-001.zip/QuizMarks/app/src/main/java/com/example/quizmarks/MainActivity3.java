package com.example.quizmarks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    int result1;
    TextView outputtextview;
    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent mygetIntent = getIntent();
        result1 = mygetIntent.getIntExtra(MainActivity2.quixmark, 0);
        outputtextview = findViewById(R.id.answertext);


        outputtextview.setText("your  marks is : " + result1 + "out of 10");


    }


    public void tryagain ( View view ) {

        Intent myfirstIntent =new Intent(MainActivity3.this, MainActivity.class);
        startActivity(myfirstIntent);


    }
}

